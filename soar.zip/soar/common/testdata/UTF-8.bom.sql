﻿select col from tb c = 1;
