package common

// -version输出信息
var (
	Version  = "No Version Provided"
	Compile  = ""
	Branch   = ""
	GitDirty = ""
	DevPath  = ""
)
