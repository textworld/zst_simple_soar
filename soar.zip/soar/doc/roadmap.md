## 路线图

* 语法支持方面，目前主要依赖vitess,TiDB对SQL语法的支持。
* 目前仅针对MySQL语法族进行开发和测试，其他使用SQL的数据库产品暂不支持。
* Profiling和Trace功能有待深入挖掘，供经验丰富的DBA分析使用。
* 目前尚不支持直接线上自动执行评审通过的SQL，后续会努力支持。
* 由于暂不支持线上自动执行，因此数据备份功能也未提供。
* Vim, Sublime, Emacs等编辑器插件支持。
* Currently, only support Chinese suggestion, if you can help us add multi-language support, it will be greatly appreciated.
