## Compare with other wonderful product

|                    | SOAR | sqlcheck | pt-query-advisor | SQL Advisor | Inception | sqlautoreview |
| ---                | ---  | ---      | ---              | ---         | ---       | ---           |
| Heuristic Rules    | ✔️    | ✔️        | ✔️                | ❌          | ✔️         | ✔️             |
| Index Suggest      | ✔️    | ❌       | ❌               | ✔️           | ❌        | ✔️             |
| Rewrite Query      | ✔️    | ❌       | ❌               | ❌          | ❌        | ❌            |
| Explain            | ✔️    | ❌       | ❌               | ❌          | ❌        | ❌            |
| Profiling          | ✔️    | ❌       | ❌               | ❌          | ❌        | ❌            |
| Trace              | ✔️    | ❌       | ❌               | ❌          | ❌        | ❌            |
| Execute SQL Online | ❌   | ❌       | ❌               | ❌          | ✔️         | ❌            |
| Backup Data        | ❌   | ❌       | ❌               | ❌          | ✔️         | ❌            |
