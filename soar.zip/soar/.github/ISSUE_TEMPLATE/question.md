---
name: Question
about: If you have a question, please check out our other community resources instead of opening an issue.

---

Issues on GitHub are intended to be related to bugs or feature requests, so we recommend using our other community resources instead of asking here.

- [SOAR Doc](http://github.com/XiaoMi/soar/blob/master/README.md)
- Any other questions can be asked in the community [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/xiaomi-dba/soar)
